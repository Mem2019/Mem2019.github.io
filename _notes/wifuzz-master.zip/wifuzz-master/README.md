# wifuzz
Automatically exported from code.google.com/p/wifuzz

WiFuzz is an Access Point 802.11 stack fuzzer. It generates "fuzzy" 802.11 network packets to trigger corner-case errors in the 802.11 stack implemented in today's Access Points.
